"""Project Manager — Gantt, milestones, budget tracking"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, date
from data.models import init_state, PROJECT_STATUSES

PLOTLY_THEME = dict(
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="DM Sans", color="#8890a4", size=12),
    margin=dict(l=0, r=0, t=30, b=0),
)

STATUS_COLORS = {
    "Planning":"#555d72","Design":"#00d4ff","Procurement":"#ffb347",
    "Construction":"#a78bfa","Commissioning":"#00e5a0","Operational":"#00e5a0",
}

def render():
    init_state()
    projects = st.session_state.projects

    st.markdown('<div class="page-title">📋 Project Manager</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-sub">Milestones · Gantt · Budget · Team</div>', unsafe_allow_html=True)

    tab_overview, tab_gantt, tab_edit, tab_new = st.tabs(["Overview", "Gantt Chart", "Edit Project", "New Project"])

    # ── OVERVIEW ─────────────────────────────────────────────────────────────
    with tab_overview:
        for i, p in enumerate(projects):
            done_ms = sum(1 for m in p["milestones"] if m["done"])
            total_ms = len(p["milestones"])
            budget_pct = round(p["spent_usd"] / p["budget_usd"] * 100, 1)
            sc = {"Planning":"badge-purple","Design":"badge-blue","Procurement":"badge-amber",
                  "Construction":"badge-amber","Commissioning":"badge-green","Operational":"badge-green"}.get(p["status"],"badge-blue")

            with st.expander(f'**{p["name"]}** — {p["status"]}', expanded=(i == 0)):
                col1, col2, col3, col4 = st.columns(4)
                col1.metric("Capacity", f"{p['capacity_mwh']} MWh")
                col2.metric("Power", f"{p['power_mw']} MW")
                col3.metric("Budget Used", f"{budget_pct}%", f"${p['spent_usd']/1e6:.2f}M of ${p['budget_usd']/1e6:.1f}M")
                col4.metric("Milestones", f"{done_ms}/{total_ms}", f"{p['progress_pct']}% done")

                st.markdown("<br>", unsafe_allow_html=True)

                # Milestone table
                st.markdown('<div class="section-title">Milestones</div>', unsafe_allow_html=True)
                for m in p["milestones"]:
                    icon = "✅" if m["done"] else "⏳"
                    color = "#00e5a0" if m["done"] else "#ffb347"
                    st.markdown(f"""
                    <div style='display:flex;align-items:center;gap:12px;padding:6px 0;
                                border-bottom:1px solid rgba(255,255,255,0.04)'>
                      <span style='font-size:14px'>{icon}</span>
                      <span style='font-size:12px;color:#e8eaf0;flex:1'>{m["name"]}</span>
                      <span style='font-family:JetBrains Mono;font-size:10px;color:{color}'>{m["date"]}</span>
                    </div>""", unsafe_allow_html=True)

                st.markdown("<br>", unsafe_allow_html=True)

                # Budget bar
                st.markdown('<div class="section-title">Budget Utilisation</div>', unsafe_allow_html=True)
                fig = go.Figure(go.Bar(
                    x=["Spent", "Remaining"],
                    y=[p["spent_usd"]/1e6, (p["budget_usd"]-p["spent_usd"])/1e6],
                    marker_color=["#00d4ff", "#1a2d4a"],
                    text=[f"${p['spent_usd']/1e6:.2f}M", f"${(p['budget_usd']-p['spent_usd'])/1e6:.2f}M"],
                    textposition="inside",
                ))
                fig.update_layout(**PLOTLY_THEME, height=160, yaxis_title="$M",
                                  yaxis=dict(gridcolor="rgba(255,255,255,0.05)"),
                                  xaxis=dict(showgrid=False))
                st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

                if p["notes"]:
                    st.info(f"📝 {p['notes']}")

    # ── GANTT ─────────────────────────────────────────────────────────────────
    with tab_gantt:
        st.markdown('<div class="section-title">Project Timeline</div>', unsafe_allow_html=True)

        gantt_rows = []
        for p in projects:
            for m in p["milestones"]:
                gantt_rows.append({
                    "Project": p["name"],
                    "Task": m["name"],
                    "Start": p["start_date"],
                    "Finish": m["date"],
                    "Status": "Complete" if m["done"] else p["status"],
                    "Resource": p["engineer"],
                })

        df = pd.DataFrame(gantt_rows)
        fig = px.timeline(
            df, x_start="Start", x_end="Finish", y="Project",
            color="Status",
            color_discrete_map={
                "Complete":"#00e5a0","Design":"#00d4ff","Procurement":"#ffb347",
                "Planning":"#555d72","Construction":"#a78bfa","Commissioning":"#00e5a0",
            },
            hover_data=["Task","Resource"],
        )
        fig.update_yaxes(autorange="reversed")
        fig.update_layout(
            **PLOTLY_THEME, height=380,
            xaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.05)"),
            yaxis=dict(showgrid=False),
            legend=dict(bgcolor="rgba(0,0,0,0)", orientation="h", y=1.1),
        )
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

        # Summary table
        st.markdown('<div class="section-title">All Milestones</div>', unsafe_allow_html=True)
        st.dataframe(
            df[["Project","Task","Finish","Status"]].rename(columns={"Finish":"Target Date"}),
            use_container_width=True, hide_index=True,
        )

    # ── EDIT PROJECT ──────────────────────────────────────────────────────────
    with tab_edit:
        proj_names = [p["name"] for p in projects]
        sel_name = st.selectbox("Select project to edit", proj_names)
        proj = next(p for p in projects if p["name"] == sel_name)
        idx = projects.index(proj)

        with st.form("edit_project_form"):
            st.markdown('<div class="section-title">Basic Info</div>', unsafe_allow_html=True)
            c1, c2 = st.columns(2)
            new_name     = c1.text_input("Project Name", proj["name"])
            new_client   = c2.text_input("Client", proj["client"])
            new_loc      = c1.text_input("Location", proj["location"])
            new_eng      = c2.text_input("Engineer", proj["engineer"])
            new_status   = st.selectbox("Status", PROJECT_STATUSES, index=PROJECT_STATUSES.index(proj["status"]))
            new_app      = st.text_input("Application", proj["application"])

            st.markdown('<div class="section-title">Technical</div>', unsafe_allow_html=True)
            c3, c4 = st.columns(2)
            new_cap  = c3.number_input("Capacity (MWh)", value=float(proj["capacity_mwh"]), step=0.5)
            new_pow  = c4.number_input("Power (MW)", value=float(proj["power_mw"]), step=0.5)
            new_chem = c3.selectbox("Chemistry", ["LFP","NMC","NCA","LTO"], index=["LFP","NMC","NCA","LTO"].index(proj["chemistry"]))
            new_racks= c4.number_input("Rack Count", value=proj["rack_count"], step=1)

            st.markdown('<div class="section-title">Budget</div>', unsafe_allow_html=True)
            c5, c6 = st.columns(2)
            new_budget = c5.number_input("Budget (USD)", value=proj["budget_usd"], step=10000)
            new_spent  = c6.number_input("Spent (USD)",  value=proj["spent_usd"],  step=1000)
            new_prog   = st.slider("Progress (%)", 0, 100, proj["progress_pct"])
            new_notes  = st.text_area("Notes", proj["notes"])

            if st.form_submit_button("💾 Save Changes"):
                projects[idx].update({
                    "name": new_name, "client": new_client, "location": new_loc,
                    "engineer": new_eng, "status": new_status, "application": new_app,
                    "capacity_mwh": new_cap, "power_mw": new_pow, "chemistry": new_chem,
                    "rack_count": new_racks, "budget_usd": new_budget, "spent_usd": new_spent,
                    "progress_pct": new_prog, "notes": new_notes,
                })
                st.session_state.projects = projects
                st.success("✓ Project saved")

    # ── NEW PROJECT ────────────────────────────────────────────────────────────
    with tab_new:
        with st.form("new_project_form"):
            st.markdown('<div class="section-title">Create New Project</div>', unsafe_allow_html=True)
            c1, c2 = st.columns(2)
            n_name    = c1.text_input("Project Name *", placeholder="BESS Site X")
            n_client  = c2.text_input("Client *", placeholder="Client Company")
            n_loc     = c1.text_input("Location", placeholder="City, Country")
            n_eng     = c2.text_input("Engineer", placeholder="Your name")
            n_status  = st.selectbox("Initial Status", PROJECT_STATUSES)
            c3, c4    = st.columns(2)
            n_cap     = c3.number_input("Capacity (MWh)", 0.1, 1000.0, 5.0, step=0.5)
            n_pow     = c4.number_input("Power (MW)", 0.1, 1000.0, 2.5, step=0.5)
            n_chem    = c3.selectbox("Chemistry", ["LFP","NMC","NCA","LTO"])
            n_app     = c4.text_input("Application", "Frequency Regulation")
            c5, c6    = st.columns(2)
            n_budget  = c5.number_input("Budget (USD)", 100000, 100000000, 4000000, step=50000)
            n_start   = c6.date_input("Start Date", date.today())
            n_end     = c5.date_input("End Date")
            n_notes   = st.text_area("Initial Notes")

            if st.form_submit_button("🚀 Create Project"):
                if not n_name or not n_client:
                    st.error("Project name and client are required.")
                else:
                    new_proj = {
                        "id": f"PRJ-{len(projects)+1:03d}",
                        "name": n_name, "client": n_client,
                        "location": n_loc, "engineer": n_eng,
                        "capacity_mwh": n_cap, "power_mw": n_pow,
                        "status": n_status, "chemistry": n_chem,
                        "application": n_app, "rack_count": 0,
                        "pcs_count": 0, "budget_usd": n_budget, "spent_usd": 0,
                        "start_date": str(n_start), "end_date": str(n_end),
                        "progress_pct": 0, "notes": n_notes,
                        "milestones": [
                            {"name": ms, "date": str(n_end), "done": False}
                            for ms in ["Design Freeze","Equipment Order","Civil Works Start",
                                       "Equipment Delivery","Commissioning Start","Commercial Operation"]
                        ],
                    }
                    st.session_state.projects.append(new_proj)
                    st.success(f"✓ Project '{n_name}' created with ID {new_proj['id']}")
