"""Dashboard — Fleet overview and KPIs"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from data.models import init_state

PLOTLY_THEME = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="DM Sans", color="#8890a4", size=12),
    margin=dict(l=0, r=0, t=30, b=0),
)

def render():
    init_state()

    st.markdown('<div class="page-title">⚡ BESS Engineering Dashboard</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-sub">Fleet overview · Live KPIs · Project status</div>', unsafe_allow_html=True)

    projects = st.session_state.projects

    # ── KPI Row ──────────────────────────────────────────────────────────────
    total_mwh   = sum(p["capacity_mwh"] for p in projects)
    total_mw    = sum(p["power_mw"] for p in projects)
    total_racks = sum(p["rack_count"] for p in projects)
    total_budget = sum(p["budget_usd"] for p in projects)
    total_spent  = sum(p["spent_usd"] for p in projects)

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        st.metric("Total Capacity", f"{total_mwh} MWh", "↑ +10 MWh pipeline")
    with c2:
        st.metric("Total Power", f"{total_mw} MW", f"{total_racks} racks")
    with c3:
        st.metric("Active Projects", str(len(projects)), "3 in progress")
    with c4:
        st.metric("Total Budget", f"${total_budget/1e6:.1f}M", f"${total_spent/1e6:.1f}M spent")
    with c5:
        utilisation = round(total_spent / total_budget * 100, 1)
        st.metric("Budget Utilisation", f"{utilisation}%", "On track")

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Charts row ───────────────────────────────────────────────────────────
    col_l, col_r = st.columns([3, 2])

    with col_l:
        st.markdown('<div class="section-title">Project Progress</div>', unsafe_allow_html=True)
        df = pd.DataFrame([{
            "Project": p["name"],
            "Progress": p["progress_pct"],
            "Status": p["status"],
            "Capacity (MWh)": p["capacity_mwh"],
        } for p in projects])

        colors = {"Planning":"#555d72","Design":"#00d4ff","Procurement":"#ffb347",
                  "Construction":"#a78bfa","Commissioning":"#00e5a0","Operational":"#00e5a0"}

        fig = go.Figure()
        for _, row in df.iterrows():
            fig.add_trace(go.Bar(
                y=[row["Project"]],
                x=[row["Progress"]],
                orientation="h",
                name=row["Status"],
                marker_color=colors.get(row["Status"], "#555d72"),
                text=f'{row["Progress"]}%',
                textposition="inside",
                insidetextanchor="start",
                hovertemplate=f"<b>{row['Project']}</b><br>Progress: {row['Progress']}%<br>Status: {row['Status']}<extra></extra>",
            ))
        fig.add_trace(go.Bar(
            y=df["Project"],
            x=[100 - p for p in df["Progress"]],
            orientation="h",
            marker_color="rgba(255,255,255,0.05)",
            showlegend=False,
            hoverinfo="skip",
        ))
        fig.update_layout(**PLOTLY_THEME, barmode="stack", height=220,
                          xaxis=dict(range=[0,100], showgrid=False, showticklabels=False),
                          yaxis=dict(showgrid=False), showlegend=False)
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

    with col_r:
        st.markdown('<div class="section-title">Capacity by Chemistry</div>', unsafe_allow_html=True)
        chem_data = {}
        for p in projects:
            chem_data[p["chemistry"]] = chem_data.get(p["chemistry"], 0) + p["capacity_mwh"]
        fig2 = go.Figure(go.Pie(
            labels=list(chem_data.keys()),
            values=list(chem_data.values()),
            hole=0.6,
            marker_colors=["#00d4ff", "#ffb347", "#a78bfa"],
            textinfo="label+percent",
            textfont_size=12,
        ))
        fig2.update_layout(**PLOTLY_THEME, height=220,
                           annotations=[dict(text=f"{total_mwh}<br>MWh", x=0.5, y=0.5, font_size=14,
                                             font_color="#e8eaf0", showarrow=False)])
        st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar": False})

    # ── Budget chart ─────────────────────────────────────────────────────────
    st.markdown('<div class="section-title">Budget vs Spend by Project</div>', unsafe_allow_html=True)
    fig3 = go.Figure()
    names = [p["name"] for p in projects]
    fig3.add_trace(go.Bar(name="Budget", x=names, y=[p["budget_usd"]/1e6 for p in projects], marker_color="#1a2d4a"))
    fig3.add_trace(go.Bar(name="Spent",  x=names, y=[p["spent_usd"]/1e6 for p in projects],  marker_color="#00d4ff"))
    fig3.update_layout(**PLOTLY_THEME, barmode="overlay", height=200,
                       yaxis=dict(title="$M", gridcolor="rgba(255,255,255,0.05)"),
                       xaxis=dict(showgrid=False),
                       legend=dict(bgcolor="rgba(0,0,0,0)", orientation="h", y=1.1))
    st.plotly_chart(fig3, use_container_width=True, config={"displayModeBar": False})

    # ── Project Cards ─────────────────────────────────────────────────────────
    st.markdown('<div class="section-title">Project Cards</div>', unsafe_allow_html=True)
    status_color = {"Planning":"badge-purple","Design":"badge-blue","Procurement":"badge-amber",
                    "Construction":"badge-amber","Commissioning":"badge-green","Operational":"badge-green"}

    for p in projects:
        done = sum(1 for m in p["milestones"] if m["done"])
        total_ms = len(p["milestones"])
        sc = status_color.get(p["status"], "badge-blue")

        st.markdown(f"""
        <div class="bess-card">
          <div style='display:flex;justify-content:space-between;align-items:flex-start'>
            <div>
              <div style='font-size:15px;font-weight:600;color:#e8eaf0'>{p["name"]} <span style='font-family:JetBrains Mono;font-size:11px;color:#555d72'>{p["id"]}</span></div>
              <div style='font-size:12px;color:#8890a4;margin-top:2px'>📍 {p["location"]} · 👤 {p["client"]}</div>
            </div>
            <span class="badge {sc}">{p["status"]}</span>
          </div>
          <div style='display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:14px 0 10px'>
            <div><div style='font-size:10px;color:#555d72;text-transform:uppercase;letter-spacing:0.06em'>Capacity</div>
                 <div style='font-family:JetBrains Mono;font-size:16px;color:#00d4ff'>{p["capacity_mwh"]} MWh</div></div>
            <div><div style='font-size:10px;color:#555d72;text-transform:uppercase;letter-spacing:0.06em'>Power</div>
                 <div style='font-family:JetBrains Mono;font-size:16px;color:#e8eaf0'>{p["power_mw"]} MW</div></div>
            <div><div style='font-size:10px;color:#555d72;text-transform:uppercase;letter-spacing:0.06em'>Chemistry</div>
                 <div style='font-family:JetBrains Mono;font-size:16px;color:#ffb347'>{p["chemistry"]}</div></div>
            <div><div style='font-size:10px;color:#555d72;text-transform:uppercase;letter-spacing:0.06em'>Milestones</div>
                 <div style='font-family:JetBrains Mono;font-size:16px;color:#00e5a0'>{done}/{total_ms}</div></div>
          </div>
          <div style='background:rgba(255,255,255,0.05);border-radius:4px;height:5px;overflow:hidden'>
            <div style='background:#00d4ff;height:100%;width:{p["progress_pct"]}%;transition:width 0.4s'></div>
          </div>
          <div style='display:flex;justify-content:space-between;margin-top:4px'>
            <span style='font-size:10px;color:#555d72'>{p["progress_pct"]}% complete</span>
            <span style='font-size:10px;color:#555d72'>Engineer: {p["engineer"]}</span>
          </div>
        </div>
        """, unsafe_allow_html=True)

    # ── Recent activity ────────────────────────────────────────────────────────
    st.markdown('<div class="section-title">Recent Activity</div>', unsafe_allow_html=True)
    activities = [
        ("🔋", "Battery rack specs updated — PRJ-001", "2 hours ago", "badge-blue"),
        ("📋", "Transformer procurement approved — PRJ-002", "Yesterday", "badge-green"),
        ("⚡", "PCS FAT report uploaded — PRJ-003", "2 days ago", "badge-amber"),
        ("🛡️", "Protection relay settings reviewed — PRJ-001", "3 days ago", "badge-purple"),
        ("📊", "Monthly report generated — All projects", "1 week ago", "badge-blue"),
    ]
    for icon, msg, time, badge in activities:
        st.markdown(f"""
        <div style='display:flex;align-items:center;gap:12px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05)'>
          <span style='font-size:16px'>{icon}</span>
          <span style='font-size:13px;color:#e8eaf0;flex:1'>{msg}</span>
          <span style='font-size:11px;color:#555d72'>{time}</span>
        </div>
        """, unsafe_allow_html=True)
