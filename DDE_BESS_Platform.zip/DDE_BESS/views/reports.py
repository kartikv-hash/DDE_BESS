"""Reports & Export — Generate and download project reports"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import json
from datetime import datetime
from data.models import init_state, COMPONENT_CATALOGUE

PLOTLY_THEME = dict(
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="DM Sans", color="#8890a4", size=12),
    margin=dict(l=0, r=0, t=30, b=0),
)

def render():
    init_state()
    projects = st.session_state.projects

    st.markdown('<div class="page-title">📊 Reports & Export</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-sub">Technical reports · BoM · Cost analysis · Data exports</div>', unsafe_allow_html=True)

    tab_summary, tab_bom, tab_cost, tab_export = st.tabs([
        "Summary Report", "Bill of Materials", "Cost Analysis", "Data Export"
    ])

    # ── SUMMARY REPORT ────────────────────────────────────────────────────────
    with tab_summary:
        proj_names = [p["name"] for p in projects]
        sel = st.selectbox("Select project", ["All Projects"] + proj_names)

        if sel == "All Projects":
            report_projects = projects
        else:
            report_projects = [p for p in projects if p["name"] == sel]

        total_mwh = sum(p["capacity_mwh"] for p in report_projects)
        total_mw  = sum(p["power_mw"] for p in report_projects)
        total_bud = sum(p["budget_usd"] for p in report_projects)
        total_spt = sum(p["spent_usd"] for p in report_projects)

        st.markdown(f"""
        <div class="bess-card-accent">
          <div style='font-family:JetBrains Mono;font-size:11px;color:#555d72;margin-bottom:8px'>
            REPORT GENERATED: {datetime.now().strftime("%Y-%m-%d %H:%M")}
          </div>
          <div style='font-size:20px;font-weight:600;color:#e8eaf0'>DDE BESS Engineering Report</div>
          <div style='font-size:13px;color:#8890a4;margin-top:4px'>{sel} · {len(report_projects)} project(s)</div>
          <div style='display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:20px'>
            <div>
              <div style='font-size:10px;color:#555d72;text-transform:uppercase;letter-spacing:.06em'>Total Capacity</div>
              <div style='font-family:JetBrains Mono;font-size:22px;color:#00d4ff'>{total_mwh} MWh</div>
            </div>
            <div>
              <div style='font-size:10px;color:#555d72;text-transform:uppercase;letter-spacing:.06em'>Total Power</div>
              <div style='font-family:JetBrains Mono;font-size:22px;color:#e8eaf0'>{total_mw} MW</div>
            </div>
            <div>
              <div style='font-size:10px;color:#555d72;text-transform:uppercase;letter-spacing:.06em'>Total Budget</div>
              <div style='font-family:JetBrains Mono;font-size:22px;color:#ffb347'>${total_bud/1e6:.1f}M</div>
            </div>
            <div>
              <div style='font-size:10px;color:#555d72;text-transform:uppercase;letter-spacing:.06em'>Spent</div>
              <div style='font-family:JetBrains Mono;font-size:22px;color:#00e5a0'>${total_spt/1e6:.1f}M</div>
            </div>
          </div>
        </div>
        """, unsafe_allow_html=True)

        # Charts
        col1, col2 = st.columns(2)
        with col1:
            st.markdown('<div class="section-title">Status Distribution</div>', unsafe_allow_html=True)
            status_counts = {}
            for p in report_projects:
                status_counts[p["status"]] = status_counts.get(p["status"], 0) + 1
            fig = go.Figure(go.Bar(
                x=list(status_counts.keys()), y=list(status_counts.values()),
                marker_color=["#00d4ff","#ffb347","#a78bfa","#00e5a0","#ff5566","#555d72"][:len(status_counts)],
            ))
            fig.update_layout(**PLOTLY_THEME, height=220, yaxis=dict(gridcolor="rgba(255,255,255,0.05)"),
                              xaxis=dict(showgrid=False))
            st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

        with col2:
            st.markdown('<div class="section-title">Progress Overview</div>', unsafe_allow_html=True)
            fig2 = go.Figure()
            for p in report_projects:
                fig2.add_trace(go.Bar(
                    name=p["name"], x=[p["name"]], y=[p["progress_pct"]],
                    text=f'{p["progress_pct"]}%', textposition="inside",
                    marker_color="#00d4ff",
                ))
            fig2.update_layout(**PLOTLY_THEME, height=220, showlegend=False,
                               yaxis=dict(range=[0,100],gridcolor="rgba(255,255,255,0.05)"),
                               xaxis=dict(showgrid=False))
            st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar": False})

        # Project detail table
        st.markdown('<div class="section-title">Project Details</div>', unsafe_allow_html=True)
        df = pd.DataFrame([{
            "ID": p["id"], "Name": p["name"], "Status": p["status"],
            "Capacity (MWh)": p["capacity_mwh"], "Power (MW)": p["power_mw"],
            "Chemistry": p["chemistry"], "Application": p["application"],
            "Progress (%)": p["progress_pct"],
            "Budget ($M)": round(p["budget_usd"]/1e6, 2),
            "Spent ($M)":  round(p["spent_usd"]/1e6, 2),
            "Engineer": p["engineer"],
        } for p in report_projects])
        st.dataframe(df, use_container_width=True, hide_index=True)

        # Download button
        csv = df.to_csv(index=False)
        st.download_button("⬇️ Download Summary CSV", csv, "bess_summary_report.csv", "text/csv")

    # ── BILL OF MATERIALS ─────────────────────────────────────────────────────
    with tab_bom:
        st.markdown('<div class="section-title">Bill of Materials Generator</div>', unsafe_allow_html=True)

        bom_project = st.selectbox("Project", [p["name"] for p in projects], key="bom_proj")
        proj = next(p for p in projects if p["name"] == bom_project)

        # Auto-generate BoM from project specs
        rack_count = proj["rack_count"]
        pcs_count  = proj["pcs_count"]
        bom_rows = [
            {"Item": "Battery Rack",          "Qty": rack_count, "Unit": "Rack",
             "Unit Cost": 85000, "Spec": f"100 kWh / 768V {proj['chemistry']}"},
            {"Item": "BMS",                   "Qty": max(1, rack_count//8), "Unit": "Unit",
             "Unit Cost": 8500, "Spec": "128-cell, CAN 2.0B"},
            {"Item": "PCS / Inverter",         "Qty": pcs_count, "Unit": "Unit",
             "Unit Cost": 120000, "Spec": "250 kW, 3L-NPC, 98.5%"},
            {"Item": "MV Transformer",         "Qty": max(1, pcs_count//2), "Unit": "Unit",
             "Unit Cost": 45000, "Spec": f"315 kVA, 11kV/400V"},
            {"Item": "VCB",                   "Qty": max(1, pcs_count), "Unit": "Unit",
             "Unit Cost": 12000, "Spec": "630A, 12kV"},
            {"Item": "Smart Meter",            "Qty": 2, "Unit": "Unit",
             "Unit Cost": 2500, "Spec": "Class 0.5S, Modbus"},
            {"Item": "Protection Relay",       "Qty": max(1, pcs_count), "Unit": "Unit",
             "Unit Cost": 6500, "Spec": "87T/51/50, IEC 61850"},
            {"Item": "SCADA / EMS",            "Qty": 1, "Unit": "System",
             "Unit Cost": 35000, "Spec": "IEC 61850, MQTT"},
            {"Item": "BESS Container (20ft)",  "Qty": max(1, rack_count//10), "Unit": "Unit",
             "Unit Cost": 25000, "Spec": "IP54, HVAC"},
            {"Item": "Cabling & Wiring",       "Qty": 1, "Unit": "Lot",
             "Unit Cost": round(proj["budget_usd"] * 0.05, -3), "Spec": "DC/AC/Control"},
            {"Item": "Civil & Structural",     "Qty": 1, "Unit": "Lot",
             "Unit Cost": round(proj["budget_usd"] * 0.08, -3), "Spec": "Foundation, fencing"},
            {"Item": "Commissioning & Testing","Qty": 1, "Unit": "Lot",
             "Unit Cost": round(proj["budget_usd"] * 0.04, -3), "Spec": "FAT, SAT"},
        ]

        for row in bom_rows:
            row["Total Cost"] = row["Qty"] * row["Unit Cost"]

        df_bom = pd.DataFrame(bom_rows)
        total = df_bom["Total Cost"].sum()

        # Styled display
        st.dataframe(
            df_bom.style.format({"Unit Cost": "${:,.0f}", "Total Cost": "${:,.0f}"}),
            use_container_width=True, hide_index=True,
        )

        col_total, col_budget = st.columns(2)
        col_total.metric("BoM Total", f"${total:,.0f}", f"${total/1e6:.2f}M")
        col_budget.metric("Budget", f"${proj['budget_usd']:,.0f}", f"{round(total/proj['budget_usd']*100)}% of budget")

        csv_bom = df_bom.to_csv(index=False)
        st.download_button("⬇️ Download BoM CSV", csv_bom, f"BoM_{proj['id']}.csv", "text/csv")

    # ── COST ANALYSIS ─────────────────────────────────────────────────────────
    with tab_cost:
        st.markdown('<div class="section-title">Cost Breakdown</div>', unsafe_allow_html=True)

        cost_proj = st.selectbox("Project", [p["name"] for p in projects], key="cost_proj")
        proj = next(p for p in projects if p["name"] == cost_proj)

        categories = {
            "Battery Racks":       proj["rack_count"] * 85000,
            "BMS":                 max(1, proj["rack_count"]//8) * 8500,
            "PCS / Inverters":     proj["pcs_count"] * 120000,
            "Transformers":        max(1, proj["pcs_count"]//2) * 45000,
            "Protection":          proj["pcs_count"] * 18500,
            "Monitoring & SCADA":  40000,
            "Civil & Structural":  round(proj["budget_usd"] * 0.08, -3),
            "Cabling":             round(proj["budget_usd"] * 0.05, -3),
            "Engineering & PM":    round(proj["budget_usd"] * 0.06, -3),
            "Commissioning":       round(proj["budget_usd"] * 0.04, -3),
        }

        col1, col2 = st.columns([3, 2])
        with col1:
            fig = go.Figure(go.Pie(
                labels=list(categories.keys()),
                values=list(categories.values()),
                hole=0.5,
                marker_colors=["#00d4ff","#00e5a0","#ffb347","#a78bfa","#ff5566",
                                "#555d72","#3d4a6b","#1a2d4a","#0d1a2e","#4a3a6b"],
                textinfo="label+percent", textfont_size=11,
            ))
            fig.update_layout(**PLOTLY_THEME, height=360,
                              annotations=[dict(text=f'${sum(categories.values())/1e6:.1f}M',
                                                x=0.5,y=0.5,font_size=16,font_color="#e8eaf0",showarrow=False)])
            st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

        with col2:
            st.markdown('<div class="section-title">Cost per MWh</div>', unsafe_allow_html=True)
            total_cost = sum(categories.values())
            cost_per_mwh = total_cost / proj["capacity_mwh"] if proj["capacity_mwh"] else 0

            st.markdown(f"""
            <div class="metric-tile" style="margin-bottom:10px">
              <div class="metric-value">${cost_per_mwh:,.0f}</div>
              <div class="metric-label">$/MWh installed</div>
            </div>
            <div class="metric-tile" style="margin-bottom:10px">
              <div class="metric-value" style="color:#ffb347">${total_cost/proj['power_mw']/1e6:.2f}M</div>
              <div class="metric-label">$/MW installed</div>
            </div>
            <div class="metric-tile">
              <div class="metric-value" style="color:#00e5a0">{round(proj['capacity_mwh']/proj['power_mw'],1)}h</div>
              <div class="metric-label">Storage duration</div>
            </div>""", unsafe_allow_html=True)

            st.markdown("<br>", unsafe_allow_html=True)
            for name, val in list(categories.items())[:5]:
                pct = val / total_cost * 100
                st.markdown(f"""
                <div style='margin-bottom:6px'>
                  <div style='display:flex;justify-content:space-between;margin-bottom:3px'>
                    <span style='font-size:11px;color:#8890a4'>{name}</span>
                    <span style='font-family:JetBrains Mono;font-size:10px;color:#e8eaf0'>{pct:.1f}%</span>
                  </div>
                  <div style='background:rgba(255,255,255,0.05);border-radius:2px;height:3px'>
                    <div style='background:#00d4ff;height:100%;width:{pct}%;border-radius:2px'></div>
                  </div>
                </div>""", unsafe_allow_html=True)

    # ── DATA EXPORT ────────────────────────────────────────────────────────────
    with tab_export:
        st.markdown('<div class="section-title">Export Options</div>', unsafe_allow_html=True)

        c1, c2 = st.columns(2)

        with c1:
            st.markdown("""
            <div class="bess-card">
              <div style='font-size:14px;font-weight:600;color:#e8eaf0;margin-bottom:4px'>📋 Full Project JSON</div>
              <div style='font-size:12px;color:#8890a4'>Complete data export including all projects, specs, milestones and budget data.</div>
            </div>""", unsafe_allow_html=True)
            all_data = {
                "export_date": datetime.now().isoformat(),
                "platform": "DDE BESS v2.0",
                "projects": st.session_state.projects,
                "component_catalogue": {k: {**v, "default_specs": v["default_specs"]}
                                         for k, v in COMPONENT_CATALOGUE.items()},
            }
            st.download_button(
                "⬇️ Download All Data (JSON)",
                json.dumps(all_data, indent=2),
                "dde_bess_full_export.json", "application/json",
            )

        with c2:
            st.markdown("""
            <div class="bess-card">
              <div style='font-size:14px;font-weight:600;color:#e8eaf0;margin-bottom:4px'>📊 Projects CSV</div>
              <div style='font-size:12px;color:#8890a4'>Flat CSV of all project KPIs for use in Excel or Power BI.</div>
            </div>""", unsafe_allow_html=True)
            df_all = pd.DataFrame([{
                "ID": p["id"], "Name": p["name"], "Status": p["status"],
                "Location": p["location"], "Client": p["client"],
                "Capacity MWh": p["capacity_mwh"], "Power MW": p["power_mw"],
                "Chemistry": p["chemistry"], "Rack Count": p["rack_count"],
                "Budget USD": p["budget_usd"], "Spent USD": p["spent_usd"],
                "Progress %": p["progress_pct"], "Engineer": p["engineer"],
            } for p in projects])
            st.download_button(
                "⬇️ Download Projects CSV",
                df_all.to_csv(index=False),
                "dde_bess_projects.csv", "text/csv",
            )

        with c1:
            st.markdown("""
            <div class="bess-card">
              <div style='font-size:14px;font-weight:600;color:#e8eaf0;margin-bottom:4px'>🔋 Component Catalogue CSV</div>
              <div style='font-size:12px;color:#8890a4'>All components with default specifications and unit costs.</div>
            </div>""", unsafe_allow_html=True)
            df_cat = pd.DataFrame([{
                "Key": k, "Label": v["label"], "Category": v["category"],
                "Unit Cost USD": v["unit_cost_usd"],
                **{f"spec_{sk}": sv for sk, sv in v["default_specs"].items()}
            } for k, v in COMPONENT_CATALOGUE.items()])
            st.download_button(
                "⬇️ Download Catalogue CSV",
                df_cat.to_csv(index=False),
                "bess_component_catalogue.csv", "text/csv",
            )

        with c2:
            st.markdown("""
            <div class="bess-card">
              <div style='font-size:14px;font-weight:600;color:#e8eaf0;margin-bottom:4px'>📅 Milestones CSV</div>
              <div style='font-size:12px;color:#8890a4'>All project milestones with completion status.</div>
            </div>""", unsafe_allow_html=True)
            ms_rows = []
            for p in projects:
                for m in p["milestones"]:
                    ms_rows.append({
                        "Project ID": p["id"], "Project": p["name"],
                        "Milestone": m["name"], "Target Date": m["date"],
                        "Done": m["done"],
                    })
            df_ms = pd.DataFrame(ms_rows)
            st.download_button(
                "⬇️ Download Milestones CSV",
                df_ms.to_csv(index=False),
                "bess_milestones.csv", "text/csv",
            )
