"""Design Canvas — Embedded BESS CAD tool with form-driven quick-add"""

import streamlit as st
import streamlit.components.v1 as components
from data.models import init_state, COMPONENT_CATALOGUE, WIRE_TYPES

# The full standalone CAD tool HTML (dark theme, all features)
CAD_HTML = """<!DOCTYPE html>
<html><head>
<meta charset="UTF-8">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:#0d0f14;color:#e8eaf0;height:100vh;display:flex;flex-direction:column;overflow:hidden}
#tb{height:40px;display:flex;align-items:center;gap:4px;padding:0 10px;background:#12151c;border-bottom:1px solid rgba(255,255,255,0.07);flex-shrink:0}
.tb-btn{padding:0 10px;height:26px;border-radius:5px;font-size:11px;font-weight:500;cursor:pointer;color:#8890a4;background:transparent;border:1px solid rgba(255,255,255,0.1);font-family:'DM Sans';transition:all 0.15s;white-space:nowrap}
.tb-btn:hover{background:#1a1e28;color:#e8eaf0}.tb-btn.active{background:rgba(0,212,255,0.15);color:#00d4ff;border-color:rgba(0,212,255,0.4)}
.sep{width:1px;height:18px;background:rgba(255,255,255,0.1);margin:0 4px}
.spacer{flex:1}
#main{display:flex;flex:1;overflow:hidden}
#sidebar{width:180px;flex-shrink:0;background:#12151c;border-right:1px solid rgba(255,255,255,0.07);overflow-y:auto;padding:8px 6px}
#sidebar::-webkit-scrollbar{width:2px}#sidebar::-webkit-scrollbar-thumb{background:#1a1e28}
.sec{font-size:9px;font-weight:600;color:#555d72;text-transform:uppercase;letter-spacing:0.08em;padding:6px 4px 4px;margin-top:6px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-bottom:4px}
.ci{display:flex;flex-direction:column;align-items:center;gap:3px;padding:6px 3px;border:1px solid rgba(255,255,255,0.07);border-radius:5px;cursor:grab;background:#1a1e28;transition:all 0.15s;user-select:none}
.ci:hover{border-color:rgba(0,212,255,0.3);background:#222738}.ci:active{cursor:grabbing}
.ci svg{width:34px;height:26px}.ci span{font-size:9px;color:#8890a4;text-align:center;line-height:1.2}
#canvas{flex:1;position:relative;overflow:hidden}
#bg{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.04) 1px,transparent 1px),linear-gradient(rgba(255,255,255,0.015) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.015) 1px,transparent 1px);background-size:100px 100px,100px 100px,20px 20px,20px 20px}
#svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible}
#sb{height:22px;display:flex;align-items:center;gap:10px;background:#12151c;border-top:1px solid rgba(255,255,255,0.07);padding:0 10px;font-family:'JetBrains Mono';font-size:10px;color:#555d72;flex-shrink:0}
</style></head><body>
<div id="tb">
  <button class="tb-btn active" id="btn-select" onclick="setTool('select')">▲ Select</button>
  <button class="tb-btn" id="btn-wire" onclick="setTool('wire')">⟋ Wire</button>
  <button class="tb-btn" id="btn-bus" onclick="setTool('bus')">━ Bus</button>
  <button class="tb-btn" id="btn-annotate" onclick="setTool('annotate')">T Text</button>
  <div class="sep"></div>
  <select id="wire-type" style="padding:2px 6px;background:#1a1e28;border:1px solid rgba(255,255,255,0.1);color:#8890a4;border-radius:5px;font-size:10px;font-family:'JetBrains Mono'">
    <option value="dc">DC Bus</option><option value="ac_hv">AC HV</option>
    <option value="ac_lv">AC LV</option><option value="ctrl">Control</option><option value="comm">Comms</option>
  </select>
  <div class="sep"></div>
  <button class="tb-btn" onclick="undo()">↩ Undo</button>
  <button class="tb-btn" onclick="zoomFit()">⊡ Fit</button>
  <button class="tb-btn" onclick="exportSVG()" style="color:#00d4ff;border-color:rgba(0,212,255,0.3)">↓ SVG</button>
  <button class="tb-btn" onclick="exportDXF()" style="color:#ffb347;border-color:rgba(255,179,71,0.3)">↓ DXF</button>
  <button class="tb-btn" onclick="clearAll()" style="color:#ff5566;border-color:rgba(255,85,102,0.3)">✕ Clear</button>
  <div class="spacer"></div>
  <span style="font-family:'JetBrains Mono';font-size:10px;color:#555d72" id="coords">X:0 Y:0</span>
</div>
<div id="main">
  <div id="sidebar">
    <div class="sec">Storage</div>
    <div class="grid">
      <div class="ci" draggable="true" data-type="battery_rack">
        <svg viewBox="0 0 34 26"><rect x="1" y="3" width="26" height="18" rx="2" fill="none" stroke="#00d4ff" stroke-width="1"/><rect x="27" y="8" width="3" height="8" rx="1" fill="#00d4ff" opacity=".5"/><rect x="3" y="6" width="4" height="12" rx="1" fill="#00d4ff" opacity=".5"/><rect x="9" y="6" width="4" height="12" rx="1" fill="#00d4ff" opacity=".4"/><rect x="15" y="6" width="4" height="12" rx="1" fill="#00d4ff" opacity=".25"/><rect x="21" y="6" width="3" height="12" rx="1" fill="#00d4ff" opacity=".15"/></svg>
        <span>Battery Rack</span></div>
      <div class="ci" draggable="true" data-type="bms">
        <svg viewBox="0 0 34 26"><rect x="3" y="2" width="28" height="22" rx="2" fill="none" stroke="#00e5a0" stroke-width="1"/><text x="17" y="14" text-anchor="middle" font-size="8" fill="#00e5a0" font-family="JetBrains Mono" font-weight="600">BMS</text><circle cx="8" cy="7" r="1.8" fill="#00e5a0" opacity=".7"/></svg>
        <span>BMS</span></div>
      <div class="ci" draggable="true" data-type="container">
        <svg viewBox="0 0 34 26"><rect x="1" y="1" width="32" height="24" rx="2" fill="none" stroke="#555d72" stroke-width="1" stroke-dasharray="3 2"/><text x="17" y="14" text-anchor="middle" font-size="6" fill="#555d72" font-family="DM Sans">CONTAINER</text></svg>
        <span>Container</span></div>
    </div>
    <div class="sec">Power</div>
    <div class="grid">
      <div class="ci" draggable="true" data-type="pcs">
        <svg viewBox="0 0 34 26"><rect x="2" y="2" width="30" height="22" rx="2" fill="none" stroke="#ffb347" stroke-width="1"/><path d="M9 13L14 7 14 11 19 11 19 16 14 16 14 21Z" fill="none" stroke="#ffb347" stroke-width="1" stroke-linejoin="round"/><text x="26" y="16" text-anchor="middle" font-size="6" fill="#ffb347" font-family="JetBrains Mono">PCS</text></svg>
        <span>PCS</span></div>
      <div class="ci" draggable="true" data-type="transformer">
        <svg viewBox="0 0 34 26"><circle cx="12" cy="13" r="8" fill="none" stroke="#a78bfa" stroke-width="1"/><circle cx="22" cy="13" r="8" fill="none" stroke="#a78bfa" stroke-width="1"/><line x1="0" y1="13" x2="4" y2="13" stroke="#a78bfa" stroke-width="1.2"/><line x1="30" y1="13" x2="34" y2="13" stroke="#a78bfa" stroke-width="1.2"/></svg>
        <span>Transformer</span></div>
      <div class="ci" draggable="true" data-type="vcb">
        <svg viewBox="0 0 34 26"><line x1="17" y1="1" x2="17" y2="9" stroke="#ff5566" stroke-width="1.5"/><circle cx="17" cy="13" r="4" fill="none" stroke="#ff5566" stroke-width="1"/><line x1="17" y1="17" x2="17" y2="25" stroke="#ff5566" stroke-width="1.5" stroke-dasharray="2 1"/></svg>
        <span>VCB</span></div>
      <div class="ci" draggable="true" data-type="busbar">
        <svg viewBox="0 0 34 26"><rect x="1" y="11" width="32" height="4" rx="1" fill="#8890a4" opacity=".6"/><line x1="9" y1="6" x2="9" y2="11" stroke="#8890a4" stroke-width="1.5"/><line x1="17" y1="6" x2="17" y2="11" stroke="#8890a4" stroke-width="1.5"/><line x1="25" y1="6" x2="25" y2="11" stroke="#8890a4" stroke-width="1.5"/></svg>
        <span>Busbar</span></div>
    </div>
    <div class="sec">Monitoring</div>
    <div class="grid">
      <div class="ci" draggable="true" data-type="meter">
        <svg viewBox="0 0 34 26"><circle cx="17" cy="13" r="10" fill="none" stroke="#00e5a0" stroke-width="1"/><path d="M8 19Q17 5 26 19" fill="none" stroke="#444" stroke-width=".8"/><line x1="17" y1="13" x2="22" y2="9" stroke="#00e5a0" stroke-width="1.5" stroke-linecap="round"/></svg>
        <span>Meter</span></div>
      <div class="ci" draggable="true" data-type="relay">
        <svg viewBox="0 0 34 26"><rect x="5" y="3" width="24" height="20" rx="2" fill="none" stroke="#00e5a0" stroke-width="1"/><text x="17" y="15" text-anchor="middle" font-size="7" fill="#00e5a0" font-family="JetBrains Mono">87T</text><circle cx="9" cy="7" r="1.8" fill="#00e5a0" opacity=".7"/></svg>
        <span>Relay</span></div>
      <div class="ci" draggable="true" data-type="grid_point">
        <svg viewBox="0 0 34 26"><path d="M17 2L30 21H4Z" fill="none" stroke="#00d4ff" stroke-width="1" stroke-linejoin="round"/><line x1="17" y1="21" x2="17" y2="25" stroke="#00d4ff" stroke-width="1.5"/><line x1="11" y1="25" x2="23" y2="25" stroke="#00d4ff" stroke-width="1.5"/></svg>
        <span>Grid Point</span></div>
      <div class="ci" draggable="true" data-type="scada">
        <svg viewBox="0 0 34 26"><rect x="4" y="3" width="26" height="17" rx="2" fill="none" stroke="#a78bfa" stroke-width="1"/><rect x="7" y="6" width="20" height="8" rx="1" fill="#a78bfa" opacity=".1"/><text x="17" y="13" text-anchor="middle" font-size="7" fill="#a78bfa" font-family="JetBrains Mono">EMS</text><rect x="12" y="22" width="10" height="2" rx=".5" fill="#a78bfa" opacity=".5"/><line x1="17" y1="20" x2="17" y2="22" stroke="#a78bfa" stroke-width="1"/></svg>
        <span>SCADA</span></div>
    </div>
  </div>
  <div id="canvas" ondragover="event.preventDefault()" ondrop="onDrop(event)"
    onmousedown="mDown(event)" onmousemove="mMove(event)" onmouseup="mUp(event)" onwheel="onWheel(event)">
    <div id="bg"></div>
    <svg id="svg">
      <defs>
        <marker id="arr" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
          <path d="M2 1.5L8 5L2 8.5" fill="none" stroke="context-stroke" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </marker>
        <filter id="sel"><feDropShadow dx="0" dy="0" stdDeviation="4" flood-color="#00d4ff" flood-opacity=".8"/></filter>
      </defs>
      <g id="root">
        <g id="wlayer"></g>
        <g id="clayer"></g>
        <g id="alayer"></g>
        <g id="tmp"></g>
      </g>
    </svg>
  </div>
</div>
<div id="sb">
  <span id="sb-mode">● Select</span>
  <span>|</span><span id="sb-comps">0 components</span>
  <span>|</span><span id="sb-wires">0 wires</span>
  <span>|</span><span id="sb-zoom">Zoom: 100%</span>
  <div style="flex:1"></div>
  <span>V=select W=wire B=bus ESC=cancel Del=delete Ctrl+Z=undo</span>
</div>
<script>
const CDEFS={battery_rack:{l:'Battery Rack',w:90,h:55,c:'#00d4ff'},bms:{l:'BMS',w:75,h:45,c:'#00e5a0'},
  container:{l:'Container',w:200,h:100,c:'#555d72',dash:true},pcs:{l:'PCS',w:80,h:60,c:'#ffb347'},
  transformer:{l:'Transformer',w:80,h:60,c:'#a78bfa'},vcb:{l:'VCB',w:50,h:65,c:'#ff5566'},
  busbar:{l:'Busbar',w:160,h:18,c:'#8890a4'},meter:{l:'Meter',w:60,h:55,c:'#00e5a0'},
  relay:{l:'Relay',w:65,h:50,c:'#00e5a0'},grid_point:{l:'Grid',w:70,h:65,c:'#00d4ff'},
  scada:{l:'SCADA',w:70,h:55,c:'#a78bfa'}};
const WSTYLES={dc:{s:'#00d4ff',w:1.5,d:''},ac_hv:{s:'#ff5566',w:2,d:''},ac_lv:{s:'#ffb347',w:1.5,d:''},
  ctrl:{s:'#a78bfa',w:1,d:'4 2'},comm:{s:'#00e5a0',w:1,d:'2 3'}};
let comps=[],wires=[],sel=null,tool='select',idN=0;
let px=0,py=0,zoom=1,panning=false,psx=0,psy=0;
let wStart=null,wPts=[],tmp=null;
let dragging=false,dc=null,dox=0,doy=0;
let undoStk=[];
let lastDT=null;

const root=()=>document.getElementById('root');
const wl=()=>document.getElementById('wlayer');
const cl=()=>document.getElementById('clayer');
const al=()=>document.getElementById('alayer');
const tmpl=()=>document.getElementById('tmp');
const svgEl=()=>document.getElementById('svg');

function applyT(){root().setAttribute('transform',`translate(${px},${py}) scale(${zoom})`);document.getElementById('sb-zoom').textContent=`Zoom: ${Math.round(zoom*100)}%`;}
function svgPt(cx,cy){const r=svgEl().getBoundingClientRect();return{x:(cx-r.left-px)/zoom,y:(cy-r.top-py)/zoom};}
function snap(v){return Math.round(v/20)*20;}
function setTool(t){tool=t;['select','wire','bus','annotate'].forEach(k=>{const b=document.getElementById('btn-'+k);if(b)b.classList.toggle('active',k===t);});document.getElementById('sb-mode').textContent='● '+t.charAt(0).toUpperCase()+t.slice(1);wStart=null;wPts=[];clearTmp();}
function saveU(){undoStk.push({c:JSON.parse(JSON.stringify(comps)),w:JSON.parse(JSON.stringify(wires))});if(undoStk.length>20)undoStk.shift();}
function undo(){if(!undoStk.length)return;const s=undoStk.pop();comps=s.c;wires=s.w;cl().innerHTML='';wl().innerHTML='';comps.forEach(renderC);wires.forEach(renderW);sel=null;updateSB();}
function updateSB(){document.getElementById('sb-comps').textContent=comps.length+' components';document.getElementById('sb-wires').textContent=wires.length+' wires';}

document.querySelectorAll('.ci').forEach(el=>{el.addEventListener('dragstart',ev=>{lastDT=el.dataset.type;ev.dataTransfer?.setData('text/plain',el.dataset.type);});});

function onDrop(e){e.preventDefault();const t=e.dataTransfer?.getData('text/plain')||lastDT;if(!t||!CDEFS[t])return;const d=CDEFS[t];const p=svgPt(e.clientX,e.clientY);saveU();addC(t,snap(p.x-d.w/2),snap(p.y-d.h/2));}

function addC(type,x,y){const d=CDEFS[type];const id='c'+(++idN);const comp={id,type,x,y,w:d.w,h:d.h,l:d.l,c:d.c,dash:d.dash};comps.push(comp);renderC(comp);updateSB();return comp;}

function renderC(comp){
  const g=document.createElementNS('http://www.w3.org/2000/svg','g');
  g.setAttribute('id',comp.id);g.setAttribute('data-id',comp.id);
  g.setAttribute('transform',`translate(${comp.x},${comp.y})`);g.style.cursor='pointer';g.style.userSelect='none';
  const r=document.createElementNS('http://www.w3.org/2000/svg','rect');
  r.setAttribute('width',comp.w);r.setAttribute('height',comp.h);r.setAttribute('rx','4');
  r.setAttribute('fill',comp.c+'15');r.setAttribute('stroke',comp.c+'CC');r.setAttribute('stroke-width','1');
  if(comp.dash){r.setAttribute('stroke-dasharray','6 3');r.setAttribute('fill','transparent');}
  g.appendChild(r);
  [[comp.w/2,0],[comp.w/2,comp.h],[0,comp.h/2],[comp.w,comp.h/2]].forEach(([tx,ty])=>{
    const d=document.createElementNS('http://www.w3.org/2000/svg','circle');
    d.setAttribute('cx',tx);d.setAttribute('cy',ty);d.setAttribute('r','4');
    d.setAttribute('fill',comp.c);d.setAttribute('opacity','0');d.setAttribute('class','term');d.setAttribute('data-id',comp.id);
    d.style.transition='opacity 0.1s';g.appendChild(d);
  });
  const t=document.createElementNS('http://www.w3.org/2000/svg','text');
  t.setAttribute('x',comp.w/2);t.setAttribute('y',comp.h-7);t.setAttribute('text-anchor','middle');
  t.setAttribute('font-size','9');t.setAttribute('fill',comp.c);t.setAttribute('font-family','DM Sans');
  t.setAttribute('font-weight','500');t.setAttribute('pointer-events','none');
  t.textContent=comp.l.length>13?comp.l.substring(0,11)+'…':comp.l;g.appendChild(t);
  g.addEventListener('mouseenter',()=>g.querySelectorAll('.term').forEach(d=>d.setAttribute('opacity','0.7')));
  g.addEventListener('mouseleave',()=>g.querySelectorAll('.term').forEach(d=>d.setAttribute('opacity','0')));
  cl().appendChild(g);
}

function mDown(e){
  if(e.button===1||(e.button===0&&e.altKey)){panning=true;psx=e.clientX-px;psy=e.clientY-py;return;}
  if(tool==='select'){const t=e.target.closest('[data-id]');if(t){const c=comps.find(x=>x.id===t.dataset.id);if(c){selectC(c);dragging=true;dc=c;const p=svgPt(e.clientX,e.clientY);dox=p.x-c.x;doy=p.y-c.y;saveU();}}else selectC(null);}
  if(tool==='wire'||tool==='bus'){const p={x:snap(svgPt(e.clientX,e.clientY).x),y:snap(svgPt(e.clientX,e.clientY).y)};if(!wStart){wStart=p;wPts=[p];}else{wPts.push(p);}}
  if(tool==='annotate'){const p=svgPt(e.clientX,e.clientY);const tx=prompt('Label:');if(tx)addAnn(snap(p.x),snap(p.y),tx);}
}
function mMove(e){
  const p=svgPt(e.clientX,e.clientY);document.getElementById('coords').textContent=`X:${Math.round(p.x)} Y:${Math.round(p.y)}`;
  if(panning){px=e.clientX-psx;py=e.clientY-psy;applyT();return;}
  if(dragging&&dc){dc.x=snap(p.x-dox);dc.y=snap(p.y-doy);document.getElementById(dc.id)?.setAttribute('transform',`translate(${dc.x},${dc.y})`);wires.filter(w=>w.pts.some(pt=>pt===wStart)).forEach(refreshW);}
  if((tool==='wire'||tool==='bus')&&wStart){
    if(!tmp){tmp=document.createElementNS('http://www.w3.org/2000/svg','line');
      tmp.setAttribute('stroke',tool==='bus'?'#8890a4':WSTYLES[document.getElementById('wire-type').value]?.s||'#00d4ff');
      tmp.setAttribute('stroke-width',tool==='bus'?'5':'1.5');tmp.setAttribute('stroke-dasharray','4 3');tmp.setAttribute('opacity','0.6');tmp.setAttribute('pointer-events','none');
      tmpl().appendChild(tmp);}
    const last=wPts[wPts.length-1];tmp.setAttribute('x1',last.x);tmp.setAttribute('y1',last.y);tmp.setAttribute('x2',snap(p.x));tmp.setAttribute('y2',snap(p.y));
  }
}
function mUp(e){
  if(panning){panning=false;return;}
  if(dragging){dragging=false;dc=null;return;}
  if((tool==='wire'||tool==='bus')&&wStart){
    const t=e.target.closest('[data-id]');const p={x:snap(svgPt(e.clientX,e.clientY).x),y:snap(svgPt(e.clientX,e.clientY).y)};
    if(t){const tc=comps.find(x=>x.id===t.dataset.id);if(tc){wPts.push({x:tc.x+tc.w/2,y:tc.y+tc.h/2});commitW();return;}}
    if(e.detail>=2){commitW();return;}
  }
}
function commitW(){if(wPts.length<2){clearTmp();wStart=null;wPts=[];return;}
  const wt=tool==='bus'?'busbar':document.getElementById('wire-type').value;
  const w={id:'w'+(++idN),pts:[...wPts],wt};wires.push(w);renderW(w);clearTmp();wStart=null;wPts=[];updateSB();saveU();}
function renderW(w){
  const ws=WSTYLES[w.wt]||{s:'#00d4ff',w:1.5,d:''};
  const p=document.createElementNS('http://www.w3.org/2000/svg','polyline');
  p.setAttribute('id',w.id);p.setAttribute('points',w.pts.map(pt=>`${pt.x},${pt.y}`).join(' '));
  p.setAttribute('fill','none');p.setAttribute('stroke',w.wt==='busbar'?'#8890a4':ws.s);
  p.setAttribute('stroke-width',w.wt==='busbar'?'5':ws.w);p.setAttribute('stroke-linecap','round');
  p.setAttribute('stroke-linejoin','round');if(ws.d)p.setAttribute('stroke-dasharray',ws.d);
  p.setAttribute('marker-end','url(#arr)');wl().appendChild(p);}
function refreshW(w){const el=document.getElementById(w.id);if(el)el.setAttribute('points',w.pts.map(pt=>`${pt.x},${pt.y}`).join(' '));}
function clearTmp(){if(tmp){tmp.remove();tmp=null;}tmpl().innerHTML='';}
function addAnn(x,y,text){const t=document.createElementNS('http://www.w3.org/2000/svg','text');t.setAttribute('x',x);t.setAttribute('y',y);t.setAttribute('font-size','12');t.setAttribute('fill','#8890a4');t.setAttribute('font-family','JetBrains Mono');t.setAttribute('pointer-events','none');t.textContent=text;al().appendChild(t);}
function selectC(comp){sel=comp;document.querySelectorAll('[data-id] rect').forEach(r=>{r.setAttribute('stroke-width','1');r.removeAttribute('filter');});if(!comp)return;const el=document.getElementById(comp.id);el?.querySelector('rect')?.setAttribute('filter','url(#sel)');el?.querySelector('rect')?.setAttribute('stroke-width','2');}
function onWheel(e){e.preventDefault();const f=e.deltaY<0?1.1:0.91;const p=svgPt(e.clientX,e.clientY);zoom=Math.min(4,Math.max(0.15,zoom*f));const r=svgEl().getBoundingClientRect();px=e.clientX-r.left-p.x*zoom;py=e.clientY-r.top-p.y*zoom;applyT();}
function zoomFit(){px=40;py=40;zoom=1;applyT();}
function clearAll(){if(!confirm('Clear canvas?'))return;comps=[];wires=[];cl().innerHTML='';wl().innerHTML='';al().innerHTML='';sel=null;updateSB();}
function exportSVG(){const s=new XMLSerializer().serializeToString(svgEl());const b=new Blob([s],{type:'image/svg+xml'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='bess-design.svg';a.click();}
function exportDXF(){let d='0\nSECTION\n2\nENTITIES\n';comps.forEach(c=>{d+=`0\nLWPOLYLINE\n8\nCOMPONENTS\n90\n4\n70\n1\n10\n${c.x}\n20\n${-c.y}\n10\n${c.x+c.w}\n20\n${-c.y}\n10\n${c.x+c.w}\n20\n${-(c.y+c.h)}\n10\n${c.x}\n20\n${-(c.y+c.h)}\n`;d+=`0\nTEXT\n8\nLABELS\n10\n${c.x+c.w/2}\n20\n${-(c.y+c.h/2)}\n30\n0\n40\n8\n1\n${c.l}\n`;});wires.forEach(w=>{d+=`0\nLWPOLYLINE\n8\nWIRES\n90\n${w.pts.length}\n70\n0\n`;w.pts.forEach(p=>{d+=`10\n${p.x}\n20\n${-p.y}\n`;});});d+='0\nENDSEC\n0\nEOF\n';const b=new Blob([d],{type:'application/dxf'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='bess-design.dxf';a.click();}
document.addEventListener('keydown',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))return;if(e.key==='v')setTool('select');if(e.key==='w')setTool('wire');if(e.key==='b')setTool('bus');if(e.key==='a')setTool('annotate');if(e.key==='Escape'){setTool('select');clearTmp();wStart=null;wPts=[];}if(e.key==='Delete'&&sel){saveU();document.getElementById(sel.id)?.remove();comps=comps.filter(c=>c.id!==sel.id);sel=null;updateSB();}if((e.ctrlKey||e.metaKey)&&e.key==='z')undo();});

// Starter layout
setTimeout(()=>{
  addC('grid_point',60,180);addC('vcb',180,180);addC('transformer',280,165);
  addC('busbar',400,192);addC('pcs',400,100);addC('pcs',400,300);
  addC('battery_rack',540,80);addC('battery_rack',540,160);
  addC('battery_rack',540,300);addC('battery_rack',540,380);
  addC('bms',660,220);addC('meter',170,80);addC('scada',660,60);
  setTimeout(()=>{
    [[{x:95,y:212},{x:170,y:212}],[{x:205,y:212},{x:270,y:212}],[{x:360,y:195},{x:390,y:195}],
     [{x:440,y:192},{x:440,y:140}],[{x:440,y:192},{x:440,y:320}],
     [{x:480,y:130},{x:530,y:110}],[{x:480,y:130},{x:530,y:190}],
     [{x:480,y:330},{x:530,y:330}],[{x:480,y:330},{x:530,y:410}]].forEach(pts=>{
      const w={id:'w'+(++idN),pts,wt:'dc'};wires.push(w);renderW(w);});
    const w={id:'w'+(++idN),pts:[{x:80,y:180},{x:170,y:110}],wt:'ac_hv'};wires.push(w);renderW(w);
    updateSB();
  },80);
},80);
</script></body></html>"""


def render():
    init_state()
    st.markdown('<div class="page-title">🎨 BESS Design Canvas</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-sub">Single-line diagram · Electrical schematic · Rack layout · Site plan</div>', unsafe_allow_html=True)

    col_canvas, col_form = st.columns([3, 1])

    with col_canvas:
        components.v1.html(CAD_HTML, height=600, scrolling=False)

    with col_form:
        st.markdown('<div class="section-title">Quick Add</div>', unsafe_allow_html=True)

        with st.expander("🔋 Battery String", expanded=True):
            rack_count = st.number_input("Rack count", 1, 20, 4, key="f_racks")
            chemistry  = st.selectbox("Chemistry", ["LFP", "NMC", "NCA", "LTO"], key="f_chem")
            cap_kwh    = st.number_input("kWh / rack", 50, 500, 100, key="f_cap")
            voltage    = st.number_input("Voltage (V DC)", 400, 1500, 768, key="f_volt")
            if st.button("Add String", key="add_string"):
                st.success(f"✓ {rack_count}× {cap_kwh} kWh {chemistry} racks — total {rack_count*cap_kwh} kWh")

        with st.expander("⚡ PCS Block"):
            pcs_kw  = st.number_input("Rated power (kW)", 50, 2000, 250, key="f_pcs")
            hv_kv   = st.number_input("HV voltage (kV)", 3, 33, 11, key="f_hv")
            topology = st.selectbox("Topology", ["3L-NPC", "2L-VSC", "Modular MLI"], key="f_topo")
            if st.button("Add PCS Block", key="add_pcs"):
                st.success(f"✓ {pcs_kw} kW PCS → {round(pcs_kw*1.25/100)*100} kVA transformer @ {hv_kv} kV")

        with st.expander("📐 Site Boundary"):
            site_w = st.number_input("Width (m)", 10, 500, 80, key="f_sw")
            site_h = st.number_input("Height (m)", 10, 500, 60, key="f_sh")
            site_label = st.text_input("Label", "BESS Site A", key="f_sl")
            if st.button("Add Site", key="add_site"):
                st.success(f"✓ Site boundary: {site_w}×{site_h} m")

        st.markdown('<div class="section-title">Wire Legend</div>', unsafe_allow_html=True)
        legend = {
            "AC HV": "#ff5566", "DC Bus": "#00d4ff",
            "AC LV": "#ffb347", "Control": "#a78bfa", "Comms": "#00e5a0",
        }
        for name, color in legend.items():
            st.markdown(f"""<div style='display:flex;align-items:center;gap:8px;margin-bottom:5px'>
              <div style='width:24px;height:2px;background:{color}'></div>
              <span style='font-size:11px;color:#8890a4'>{name}</span>
            </div>""", unsafe_allow_html=True)

        st.markdown('<div class="section-title">Export</div>', unsafe_allow_html=True)
        st.info("Use the SVG / DXF / Clear buttons inside the canvas toolbar above.", icon="ℹ️")
