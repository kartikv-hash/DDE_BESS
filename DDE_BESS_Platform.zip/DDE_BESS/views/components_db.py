"""Component Database — searchable, editable component catalogue"""

import streamlit as st
import pandas as pd
from data.models import init_state, COMPONENT_CATALOGUE

def render():
    init_state()

    st.markdown('<div class="page-title">🔋 Component Database</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-sub">Searchable catalogue · Specifications · Cost data</div>', unsafe_allow_html=True)

    # ── Search & filters ──────────────────────────────────────────────────────
    col_search, col_cat, col_sort = st.columns([3, 2, 2])
    with col_search:
        search = st.text_input("Search components", placeholder="e.g. battery, transformer…", label_visibility="collapsed")
    with col_cat:
        categories = ["All"] + sorted(set(v["category"] for v in COMPONENT_CATALOGUE.values()))
        cat_filter = st.selectbox("Category", categories, label_visibility="collapsed")
    with col_sort:
        sort_by = st.selectbox("Sort by", ["Name", "Category", "Cost ↑", "Cost ↓"], label_visibility="collapsed")

    # ── Summary row ────────────────────────────────────────────────────────────
    total_types = len(COMPONENT_CATALOGUE)
    total_cost  = sum(v["unit_cost_usd"] for v in COMPONENT_CATALOGUE.values())
    cats = sorted(set(v["category"] for v in COMPONENT_CATALOGUE.values()))

    c1, c2, c3 = st.columns(3)
    c1.metric("Component Types", total_types)
    c2.metric("Categories", len(cats))
    c3.metric("Avg Unit Cost", f"${total_cost//total_types:,.0f}")

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Filter logic ──────────────────────────────────────────────────────────
    items = [
        {"key": k, **v, "unit_cost_usd": v["unit_cost_usd"]}
        for k, v in COMPONENT_CATALOGUE.items()
    ]
    if search:
        items = [i for i in items if search.lower() in i["label"].lower() or search.lower() in i["category"].lower()]
    if cat_filter != "All":
        items = [i for i in items if i["category"] == cat_filter]
    if sort_by == "Name":
        items.sort(key=lambda x: x["label"])
    elif sort_by == "Category":
        items.sort(key=lambda x: x["category"])
    elif sort_by == "Cost ↑":
        items.sort(key=lambda x: x["unit_cost_usd"])
    elif sort_by == "Cost ↓":
        items.sort(key=lambda x: x["unit_cost_usd"], reverse=True)

    # ── Category tabs ─────────────────────────────────────────────────────────
    cat_tabs = ["All"] + sorted(set(i["category"] for i in items))
    tab_objs = st.tabs(cat_tabs)

    for tab, cat_name in zip(tab_objs, cat_tabs):
        with tab:
            filtered = items if cat_name == "All" else [i for i in items if i["category"] == cat_name]

            for item in filtered:
                color = item["color"]
                with st.expander(f'{item["icon"]}  {item["label"]}  —  {item["category"]}', expanded=False):
                    colA, colB = st.columns([2, 1])
                    with colA:
                        st.markdown(f'<div class="section-title">Specifications</div>', unsafe_allow_html=True)
                        specs = item["default_specs"]
                        rows_html = ""
                        for k, v in specs.items():
                            label = k.replace("_", " ").title()
                            rows_html += f"""
                            <div style='display:flex;justify-content:space-between;align-items:center;
                                        padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.04)'>
                              <span style='font-size:11px;color:#8890a4'>{label}</span>
                              <span style='font-family:JetBrains Mono;font-size:11px;color:#e8eaf0;
                                          background:#1a1e28;padding:2px 8px;border-radius:4px'>{v}</span>
                            </div>"""
                        st.markdown(f'<div style="padding:4px 0">{rows_html}</div>', unsafe_allow_html=True)

                    with colB:
                        st.markdown(f'<div class="section-title">Cost & Info</div>', unsafe_allow_html=True)
                        cost = item["unit_cost_usd"]
                        st.markdown(f"""
                        <div class="metric-tile" style="margin-bottom:10px">
                          <div class="metric-value" style="color:{color}">${cost:,}</div>
                          <div class="metric-label">Unit Cost (USD)</div>
                        </div>""", unsafe_allow_html=True)

                        st.markdown(f"""
                        <div style='background:#1a1e28;border:1px solid rgba(255,255,255,0.07);
                                    border-radius:8px;padding:14px'>
                          <div style='font-size:10px;color:#555d72;margin-bottom:6px;text-transform:uppercase;letter-spacing:.06em'>Details</div>
                          <div style='font-family:JetBrains Mono;font-size:10px;color:#8890a4;line-height:1.8'>
                            Key: <span style='color:#e8eaf0'>{item["key"]}</span><br>
                            Category: <span style='color:{color}'>{item["category"]}</span><br>
                            Specs: <span style='color:#e8eaf0'>{len(specs)} parameters</span>
                          </div>
                        </div>""", unsafe_allow_html=True)

                        st.markdown("<br>", unsafe_allow_html=True)
                        with st.form(f"edit_{item['key']}"):
                            st.markdown("**Quick edit unit cost**")
                            new_cost = st.number_input("Cost (USD)", value=cost, step=500, key=f"cost_{item['key']}")
                            if st.form_submit_button("Update"):
                                COMPONENT_CATALOGUE[item["key"]]["unit_cost_usd"] = new_cost
                                st.success("Updated ✓")

    # ── Export table ─────────────────────────────────────────────────────────
    st.markdown('<div class="section-title">Export Catalogue</div>', unsafe_allow_html=True)
    df = pd.DataFrame([{
        "Component": v["label"],
        "Category": v["category"],
        "Unit Cost (USD)": v["unit_cost_usd"],
        "Key Spec 1": list(v["default_specs"].values())[0] if v["default_specs"] else "",
    } for v in COMPONENT_CATALOGUE.values()])

    col_dl1, col_dl2 = st.columns(2)
    with col_dl1:
        csv = df.to_csv(index=False)
        st.download_button("⬇️ Download CSV", csv, "bess_components.csv", "text/csv")
    with col_dl2:
        st.dataframe(df, use_container_width=True, hide_index=True)
