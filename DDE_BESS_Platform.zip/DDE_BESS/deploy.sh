#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  DDE BESS — GitHub Push & Streamlit Deploy Script
#  Usage: bash deploy.sh YOUR_GITHUB_TOKEN
# ─────────────────────────────────────────────────────────────

TOKEN=$1
REPO="kartikv-hash/DDE_BESS"

if [ -z "$TOKEN" ]; then
  echo "❌  Usage: bash deploy.sh YOUR_GITHUB_TOKEN"
  echo ""
  echo "   Get a token at: https://github.com/settings/tokens"
  echo "   Required scopes: repo"
  exit 1
fi

echo "⚡ DDE BESS Platform — Deploy Script"
echo "──────────────────────────────────────"

# Set remote with token
git remote set-url origin "https://${TOKEN}@github.com/${REPO}.git"

# Push
echo "📤 Pushing to GitHub..."
git push origin main

if [ $? -eq 0 ]; then
  echo ""
  echo "✅ Code pushed to https://github.com/${REPO}"
  echo ""
  echo "🚀 Deploy on Streamlit Cloud (free):"
  echo "   1. Go to https://share.streamlit.io"
  echo "   2. Click 'New app'"
  echo "   3. Repository: ${REPO}"
  echo "   4. Main file path: app.py"
  echo "   5. Click Deploy"
  echo ""
  echo "🖥️  Run locally:"
  echo "   pip install -r requirements.txt"
  echo "   streamlit run app.py"
else
  echo "❌ Push failed. Check your token has 'repo' scope."
fi
