"""
Shared data models, session state helpers, and component definitions
"""

import streamlit as st
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional
from datetime import datetime, date
import json

# ── Component Catalogue ───────────────────────────────────────────────────────
COMPONENT_CATALOGUE = {
    "battery_rack": {
        "label": "Battery Rack",
        "category": "Storage",
        "icon": "🔋",
        "color": "#00d4ff",
        "default_specs": {
            "capacity_kwh": 100,
            "nominal_voltage_v": 768,
            "chemistry": "LFP",
            "max_soc_pct": 95,
            "min_soc_pct": 10,
            "cycle_life": 6000,
            "c_rate": 0.5,
            "weight_kg": 1200,
            "dimensions_mm": "2000×800×2200",
            "ip_rating": "IP54",
        },
        "unit_cost_usd": 85000,
    },
    "bms": {
        "label": "Battery Management System",
        "category": "Control",
        "icon": "🖥️",
        "color": "#00e5a0",
        "default_specs": {
            "protocol": "CAN 2.0B",
            "cell_monitoring_channels": 128,
            "temp_sensors": 16,
            "balancing": "Active",
            "communication": "Modbus RTU / Ethernet",
            "firmware": "v3.2.1",
        },
        "unit_cost_usd": 8500,
    },
    "pcs": {
        "label": "Power Conversion System",
        "category": "Power",
        "icon": "⚡",
        "color": "#ffb347",
        "default_specs": {
            "rated_power_kw": 250,
            "efficiency_pct": 98.5,
            "topology": "3L-NPC",
            "ac_voltage_v": 400,
            "dc_voltage_range_v": "600–1000",
            "cooling": "Forced Air",
            "thd_pct": 3,
            "response_time_ms": 20,
        },
        "unit_cost_usd": 120000,
    },
    "transformer": {
        "label": "MV Transformer",
        "category": "Power",
        "icon": "🔄",
        "color": "#a78bfa",
        "default_specs": {
            "rating_kva": 315,
            "hv_kv": 11,
            "lv_v": 400,
            "vector_group": "Dyn11",
            "impedance_pct": 4.5,
            "losses_kw": 3.2,
            "cooling": "ONAN",
        },
        "unit_cost_usd": 45000,
    },
    "vcb": {
        "label": "Vacuum Circuit Breaker",
        "category": "Protection",
        "icon": "🔌",
        "color": "#ff5566",
        "default_specs": {
            "rated_current_a": 630,
            "rated_voltage_kv": 12,
            "breaking_capacity_ka": 16,
            "type": "Vacuum",
            "standard": "IEC 62271-100",
        },
        "unit_cost_usd": 12000,
    },
    "meter": {
        "label": "Smart Energy Meter",
        "category": "Monitoring",
        "icon": "📊",
        "color": "#00e5a0",
        "default_specs": {
            "accuracy_class": "0.5S",
            "measurements": "P / Q / E / PF / THD",
            "communication": "Modbus RTU",
            "sampling_rate_hz": 50,
            "display": "LCD",
            "standard": "IEC 62053-22",
        },
        "unit_cost_usd": 2500,
    },
    "relay": {
        "label": "Protection Relay",
        "category": "Protection",
        "icon": "🛡️",
        "color": "#00e5a0",
        "default_specs": {
            "functions": "87T / 51 / 50 / 27 / 59",
            "IEC_61850": "Yes",
            "vendor": "SEL / GE / Siemens",
            "communication": "IEC 61850 / Modbus",
        },
        "unit_cost_usd": 6500,
    },
    "scada": {
        "label": "SCADA / EMS",
        "category": "Control",
        "icon": "🖧",
        "color": "#a78bfa",
        "default_specs": {
            "protocol": "IEC 61850 / MQTT",
            "redundancy": "Hot-standby",
            "response_ms": 100,
            "data_historian": "Yes",
            "cybersecurity": "IEC 62443",
        },
        "unit_cost_usd": 35000,
    },
    "grid_point": {
        "label": "Grid Connection Point",
        "category": "Grid",
        "icon": "🔗",
        "color": "#00d4ff",
        "default_specs": {
            "voltage_kv": 11,
            "frequency_hz": 50,
            "scc_ka": 10,
            "poc": "HV Substation",
            "metering": "Bidirectional",
        },
        "unit_cost_usd": 0,
    },
}

WIRE_TYPES = {
    "AC HV":    {"color": "#ff5566", "dash": False, "width": 2},
    "DC Bus":   {"color": "#00d4ff", "dash": False, "width": 1.5},
    "AC LV":    {"color": "#ffb347", "dash": False, "width": 1.5},
    "Control":  {"color": "#a78bfa", "dash": True,  "width": 1},
    "Comms":    {"color": "#00e5a0", "dash": True,  "width": 1},
    "Busbar":   {"color": "#8890a4", "dash": False, "width": 5},
}

PROJECT_STATUSES = ["Planning", "Design", "Procurement", "Construction", "Commissioning", "Operational"]

# ── Session state initialiser ────────────────────────────────────────────────
def init_state():
    defaults = {
        "components": [],          # list of component dicts on canvas
        "wires": [],               # list of wire dicts
        "projects": _seed_projects(),
        "active_project_idx": 0,
        "selected_comp_idx": None,
        "canvas_zoom": 1.0,
        "undo_stack": [],
        "notifications": [],
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

def _seed_projects():
    return [
        {
            "id": "PRJ-001",
            "name": "BESS Site Alpha",
            "location": "Manchester, UK",
            "client": "National Grid ESO",
            "capacity_mwh": 5.0,
            "power_mw": 2.5,
            "status": "Design",
            "start_date": "2024-03-01",
            "end_date": "2025-09-30",
            "budget_usd": 4_200_000,
            "spent_usd": 680_000,
            "chemistry": "LFP",
            "application": "Frequency Regulation",
            "rack_count": 50,
            "pcs_count": 4,
            "engineer": "K. Varma",
            "progress_pct": 32,
            "notes": "Grid connection approved. Transformer procurement in progress.",
            "milestones": [
                {"name": "Design Freeze",       "date": "2024-06-01", "done": True},
                {"name": "Equipment Order",     "date": "2024-08-15", "done": True},
                {"name": "Civil Works Start",   "date": "2024-11-01", "done": False},
                {"name": "Equipment Delivery",  "date": "2025-03-15", "done": False},
                {"name": "Commissioning Start", "date": "2025-07-01", "done": False},
                {"name": "Commercial Operation","date": "2025-09-30", "done": False},
            ],
        },
        {
            "id": "PRJ-002",
            "name": "Solar+Storage Beta",
            "location": "Birmingham, UK",
            "client": "Sunpower Renewables",
            "capacity_mwh": 10.0,
            "power_mw": 5.0,
            "status": "Procurement",
            "start_date": "2024-01-15",
            "end_date": "2025-12-31",
            "budget_usd": 8_500_000,
            "spent_usd": 2_100_000,
            "chemistry": "NMC",
            "application": "Peak Shaving / Solar Firming",
            "rack_count": 100,
            "pcs_count": 8,
            "engineer": "K. Varma",
            "progress_pct": 55,
            "notes": "PCS units ordered. Civil works 40% complete.",
            "milestones": [
                {"name": "Design Freeze",       "date": "2024-03-01", "done": True},
                {"name": "Equipment Order",     "date": "2024-05-01", "done": True},
                {"name": "Civil Works Start",   "date": "2024-07-01", "done": True},
                {"name": "Equipment Delivery",  "date": "2025-01-15", "done": False},
                {"name": "Commissioning Start", "date": "2025-09-01", "done": False},
                {"name": "Commercial Operation","date": "2025-12-31", "done": False},
            ],
        },
        {
            "id": "PRJ-003",
            "name": "Grid Freq. Regulation",
            "location": "Leeds, UK",
            "client": "Octopus Energy",
            "capacity_mwh": 2.0,
            "power_mw": 2.0,
            "status": "Commissioning",
            "start_date": "2023-06-01",
            "end_date": "2024-06-30",
            "budget_usd": 2_000_000,
            "spent_usd": 1_850_000,
            "chemistry": "LFP",
            "application": "FFR / BM Participation",
            "rack_count": 20,
            "pcs_count": 2,
            "engineer": "K. Varma",
            "progress_pct": 88,
            "notes": "FAT complete. Site acceptance testing ongoing.",
            "milestones": [
                {"name": "Design Freeze",       "date": "2023-08-01", "done": True},
                {"name": "Equipment Order",     "date": "2023-09-01", "done": True},
                {"name": "Civil Works Start",   "date": "2023-11-01", "done": True},
                {"name": "Equipment Delivery",  "date": "2024-02-01", "done": True},
                {"name": "Commissioning Start", "date": "2024-04-01", "done": True},
                {"name": "Commercial Operation","date": "2024-06-30", "done": False},
            ],
        },
    ]
