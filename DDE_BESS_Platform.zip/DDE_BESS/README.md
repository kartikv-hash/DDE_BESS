# DDE BESS Platform ⚡

**Battery Energy Storage System — Engineering Design Platform**

A full-stack Streamlit application for BESS project design, engineering, and management.

## Features

- 🏠 **Dashboard** — Fleet KPIs, project cards, budget vs spend, Gantt overview
- 🎨 **Design Canvas** — Interactive CAD tool with drag-and-drop, wire routing, SVG/DXF/JSON export
- 🔋 **Component Database** — 14 component types, searchable specs, cost data
- 📋 **Project Manager** — Milestones, Gantt chart, budget tracking, create/edit projects
- 📊 **Reports & Export** — BoM generator, cost analysis, CSV/JSON downloads

## Quick Start

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy

Push to GitHub → [share.streamlit.io](https://share.streamlit.io) → connect `kartikv-hash/DDE_BESS` → `app.py`

## Stack

Streamlit · Plotly · Pandas · HTML5 CAD Canvas
